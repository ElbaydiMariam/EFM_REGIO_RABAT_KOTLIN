public class User {
    private var
}
